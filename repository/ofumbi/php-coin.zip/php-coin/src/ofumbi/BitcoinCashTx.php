<?php
namespace ofumbi;
use Illuminate\Support\Collection;
use Btccom\BitcoinCash\Address\AddressCreator;
//use \BitWasp\Bitcoin\Address\AddressCreator;
use ofumbi\BitcoinTx
use Btccom\BitcoinCash\Transaction\Factory\Checker\CheckerCreator as BitcoinCashCheckerCreator;
class BitcoinCashTx extends BitcoinTx
{
	
	
	public function getTX($to , $utxos){
		\BitWasp\Bitcoin\Bitcoin::setNetwork($this->api->network);
		$AddressCreator =  new AddressCreator;
        $TX = (new \BitWasp\Bitcoin\Transaction\Factory\TxBuilder())->version(2);
	        foreach ($to as $out) {
				$TX->payToAddress($out['amount'],$AddressCreator->fromString($out['address'], $this->api->network));
		}
		$signInfo = [];
		$privateKeys = [];
        foreach ($utxos as $utxo) {
			foreach ($utxo->address->multisig->xpub->getKeys() as $key) {
				try{
					$privateKeys[] = $key->getPrivateKey($this->api->network);
				}catch(\Exception $e){
				}
			}
			if (count($privateKeys) < 2 ) throw new Exception('Address '.$utxo->address->add.' requires at least two private Keys');
			$signInfo[] = new SignInfo($privateKeys, new \BitWasp\Bitcoin\Transaction\TransactionOutput($to->sum('amount'), $utxo->scriptPubKey),$utxo->address->multisig->redeemscript);
		
			assert($utxo->address->multisig->redeemscript->getOutputScript() == $utxo->scriptPubKey );
			$TX->spendOutPoint(new \BitWasp\Bitcoin\Transaction\OutPoint(\BitWasp\Buffertools\Buffer::hex($utxo->txId), $utxo->index), $utxo->scriptPubKey);
			
        }
		$rawtx = $TX->get();
		$ecAdapter = \BitWasp\Bitcoin\Bitcoin::getEcAdapter();
		$signer = new \BitWasp\Bitcoin\Transaction\Factory\Signer($rawtx, $ecAdapter);
		$checkerCreator = BitcoinCashCheckerCreator::fromEcAdapter($ecAdapter);
		$signer->setCheckerCreator($checkerCreator);
		$sigHash = $this->api->sigHash();
	    foreach ($signInfo as $idx => $info) {
			$redeemScript = $info->redeemScript;
			$txInput = $info->output;
			$keys = $info->keys;
			$signData = (new \BitWasp\Bitcoin\Transaction\Factory\SignData())->p2sh($redeemScript);
			foreach($keys as $key){
				$signer->sign($idx, $key, $txInput, $signData , $sigHash);
			}
        }
        return $signer->get();
    }
	
}

