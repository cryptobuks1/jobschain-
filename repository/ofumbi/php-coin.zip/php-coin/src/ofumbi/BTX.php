<?php
namespace ofumbi;
class BTX
{
	public $hash;
	public $from;
	public $to;
	public $fee;
	public $amount;
	public $type;
	public $confirmations;
	public $blockHeight;
	public function __construct()
	{
		
  	}
	
}

