<?php
namespace ofumbi\Api;
use ofumbi\Api\Providers\Insight;
use Graze\GuzzleHttp\JsonRpc\Client;
use BitWasp\Bitcoin\Network\NetworkFactory;
use ofumbi\Api\ApiInterface;
use \BitWasp\Bitcoin\Transaction\SignatureHash\SigHash;
use \Btccom\BitcoinCash\Transaction\SignatureHash\SigHash as BchSigHash;
use \Btccom\BitcoinCash\Network\Networks\BitcoinCashTestnet;
class BCHTESTNET implements ApiInterface
{
	public $bip44index = '145';
	private  $blockdozer ,  // api providers
			 $bitpay , 
			
			 $net;

    public function __construct( $testnet = false ) 
    {
		$this->net = $this->network();
		$this->bitpay = new Insight('https://test-bch-insight.bitpay.com/api');
		$this->blockdozer = new Insight('https://tbch.blockdozer.com/insight/api'); 
		 
		
	}
	
	public function getNetwork(){
		return $this->net;
	}
	
	
	 /**
     * @return NetworkInterface
     * @throws \Exception
     */
    private function network()
    {
        return new BitcoinCashTestnet();
    }

    /**
     * @return NetworkInterface
     * @throws \Exception
     */
    private function testnet()
    {
        return new Networks\BitcoincashTestnet();
    }
	
	public function sigHash(){
		return BchSigHash::BITCOINCASH | SigHash::ALL;
	}

	//chainso
	public function addressTx(\Illuminate\Support\Collection $addresses , $blocks = []){
		return $this->bitpay->addressTx($addresses, $blocks);
	}
	
	// dash
	public function listunspent($minconf, array $addresses=[], $max = null){
		return $this->bitpay->listunspent($minconf, $addresses, $max);
	}
	
	//trezor
	public function getBalance($minConf, array $addresses=[]){
		$this->blockdozer->getBalance($minConf, $addresses );
	}
	
	public function sendrawtransaction( $hexRawTx ){
		return $this->blockdozer->sendrawtransaction( $hexRawTx );
	}
	
	public function getBlock($hash){
		return $this->blockdozer->getBlock($hash);
	}
	
	public function getBlockByNumber($number){
		return $this->getBlock($number);
	}
	
	public function getTx($hash){
		return $this->blockdozer->getTx($hash);
	}
	
	public function currentBlock(){
		return $this->bitpay->currentBlock();
	}
	
	public function feePerKB(){
		return $this->bitpay->feePerKB();;
	}
	//
	public function importaddress($address,$wallet_name =null,$rescan =null){
		return false;
	}
	
	
}

