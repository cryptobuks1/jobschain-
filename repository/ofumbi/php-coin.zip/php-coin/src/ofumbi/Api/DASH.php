<?php
namespace ofumbi\Api;
use ofumbi\Api\Providers\Insight;
use ofumbi\Api\Providers\Chainso;
use Graze\GuzzleHttp\JsonRpc\Client;
use ofumbi\Api\ApiInterface;
class DASH implements ApiInterface
{
	public $bip44index = '5';
	public  $apiOne ,  // api providers
			$apiTwo ,  
			$apiThree, 
			$apiFour, 
			$apiFive,
			$chainso, 
			$apiSix,
			$net;

    public function __construct(  ) 
    {
		$this->net = $this->network();
		//addressTx
		$this->apiOne = new Insight('http://insight.masternode.io:3000/api/'); 
		//listunspent
		$this->apiTwo = new Insight('https://insight.dash.org/api/');
		//getBlock
		$this->apiThree = new Insight('https://dash-bitcore1.trezor.io/api/');  
		//getBalance
		$this->apiFour = new Insight('https://dash-bitcore2.trezor.io/api/');
		//sendrawtransaction //currentBlock
		$this->apiFive = new Insight('https://dash-bitcore3.trezor.io/api/'); 
		//getTx feePerKB
		$this->apiSix = new Insight('https://insight.dash.siampm.com/api/'); 	
		
		
	}
	public function getNetwork(){
		return $this->net;
	}
	
	public function sigHash(){
		return  \BitWasp\Bitcoin\Transaction\SignatureHash\SigHash::ALL;
	}
	
	
	 /**
     * @return NetworkInterface
     * @throws \Exception
     */
    protected function network()
    {
        return \BitWasp\Bitcoin\Network\NetworkFactory::dash();
		//return \BitWasp\Bitcoin\Network\NetworkFactory::dashTestnet();
    }
	
	
	
   
	//chainso
	public function addressTx(\Illuminate\Support\Collection $addresses , $blocks = []){
	
		return $this->apiOne->addressTx($addresses, $blocks);
	}
	
	// dash
	public function listunspent($minconf, array $addresses=[], $max = null){
		return $this->apiTwo->listunspent($minconf, $addresses, $max);
	}
	
	//trezor
	public function getBalance($minConf, array $addresses=[]){
		return $this->apiFour->getBalance($minConf, $addresses );
	}
	
	public function sendrawtransaction( $hexRawTx ){
		return $this->apiFive->sendrawtransaction( $hexRawTx );
	}
	
	public function getBlock($hash){
		return $this->apiThree->getBlock($hash);
	}
	
	public function getBlockByNumber($number){
		return $this->getBlock($number);
	}
	
	public function getTx($hash){
		return $this->apiSix->getTx($hash);
	}
	
	public function currentBlock(){
		return $this->apiFive->currentBlock();
	}
	
	public function feePerKB(){
		return $this->apiSix->feePerKB();;
	}
	//
	public function importaddress($address,$wallet_name =null,$rescan =null){
		return false;
	}
	
	
}

