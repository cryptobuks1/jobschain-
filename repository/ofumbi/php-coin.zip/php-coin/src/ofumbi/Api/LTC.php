<?php
namespace ofumbi\Api;
use ofumbi\Api\Providers\Insight;
use ofumbi\Api\Providers\Chainso;
use Graze\GuzzleHttp\JsonRpc\Client;
use ofumbi\Api\ApiInterface;
class LTC implements ApiInterface
{
	public $bip44index = '2';
	public  $apiOne ,  
			 $apiTwo, 
			 $apiThree, 
			 $apiFour,
			 $apiFive, 
			 $apiSix,
			 $net;

    public function __construct(  ) 
    {
		$this->net = $this->network();
		$this->apiOne = new Insight('https://insight.litecore.io/api/');
		$this->apiTwo = new Insight('https://ltc-bitcore1.trezor.io/api/');  //listunspent
		$this->apiThree = new Insight('https://ltc-bitcore2.trezor.io/api/');	// balance 
		$this->apiFour = new Insight('https://ltc-bitcore3.trezor.io/api/');  // pushTx
		$this->apiFive = new  Chainso('LTC');
		$this->apiSix = new Insight('https://ltc.coin.space/api/');  //get Block
	}
	public function getNetwork(){
		return $this->net;
	}
	
	 /**
     * @return NetworkInterface
     * @throws \Exception
     */
    protected function network()
    {
        return \BitWasp\Bitcoin\Network\NetworkFactory::litecoin();
		//return \BitWasp\Bitcoin\Network\NetworkFactory::litecoinTestnet();
    }
	
	public function sigHash(){
		return  \BitWasp\Bitcoin\Transaction\SignatureHash\SigHash::ALL;
	}
	
	
    
	public function addressTx(\Illuminate\Support\Collection $addresses , $blocks = []){
		return $this->apiFour->addressTx($addresses, $blocks);
	}
	
	// litecoin
	public function listunspent($minconf, array $addresses=[], $max = null){
		return $this->apiOne->listunspent($minconf, $addresses, $max);
	}
	
	//trezor
	public function getBalance($minConf, array $addresses=[]){
		return $this->apiThree->getBalance($minConf, $addresses );
	}
	
	public function sendrawtransaction( $hexRawTx ){
		return $this->apiFour->sendrawtransaction( $hexRawTx );
	}
	
	public function getBlock($hash){
		return $this->apiTwo->getBlock($hash);
	}
	
	public function getBlockByNumber($number){
		return $this->getBlock($number);
	}
	
	public function getTx($hash){
		return $this->apiSix->getTx($hash);
	}
	
	public function currentBlock(){
		return $this->apiSix->currentBlock();
	}
	
	public function feePerKB(){
		return $this->apiSix->feePerKB();
	}
	
	//
	public function importaddress($address,$wallet_name =null,$rescan =null){
		return false;
	}
	
	
}

