<?php
namespace ofumbi\Api\Providers;
use ofumbi\Api\Providers\Provider;
use ofumbi\Api\ApiInterface;
use Graze\GuzzleHttp\JsonRpc\Client;

class Rpc extends Provider implements ApiInterface
{
    
    public function __construct( $url, $username , $password )
    {
        parent::__construct( $url, $username , $password );
    }
	
	
	public function listunspent($minconf, array $addresses=[], $max = null){
		$return = [];
		$method = 'listunspent';
		$params = [$minconf, $max , $addresses];
		$resp = $this->jsonRequest($method, $params);
		if(count($resp) ):;
		$return = array_map(function($o){
			$o->satoshis = $this->toSatoshi($o->amount);
			$o->ts = time();
			return $o;
		}, $resp);
		endif;
		return $return; 
	}
	
	
	
	public function importaddress($address,$wallet_name = null,$rescan =null){
		$method = 'importaddress';
		$params = [$address,$wallet_name?$wallet_name:"", $rescan !=null];
		return $this->jsonRequest($method, $params);
	
	}
	
	public function sendrawtransaction( $hexRawTx ){
		$method = 'sendrawtransaction';
		$params = [$hexRawTx];
		return $this->rpcRequest($method, $params);
	}
	
	
	public function addressTx(array $addresses=[], $blocks = []){
		$valid = [];
		foreach($blocks as $blck){
			$block = $this->getBlockByNumber($blck);
			foreach($block->txs as $tx){
				$vout  = collect($tx->outputs);
				$vin  = collect($tx->inputs);
				$all_from = $vin->pluck('address');
				$all_to = $vout->pluck('address');
				$mine_from = $all_from->intersect($addresses);
				$mine_to = $all_to->intersect($addresses);
				/*if($mine_from->count()){
					$btx = new \ofumbi\BTX;
					$btx->from = $mine_from;
					$btx->type = 'send'; 
					$btx->to = $all_to;
					$btx->hash = $tx->txid ;
					$btx->fee = $tx->fee;
					$btx->amount = $this->toSatoshi($vin->whereIn('address', $mine_from)->sum('value'));
					$btx->confirmations = isset($block->confirmations)?$block->confirmations:0;
					$btx->blockHeight = $block->block_no;
					$valid[] = $btx;
				}*/
				
				if($mine_to->count()){
					$btx = new \ofumbi\BTX;
					$btx->from = $all_from;
					$btx->type = 'receive'; 
					$btx->to = $mine_to;
					$btx->fee = $tx->fee;
					$btx->hash = $tx->txid;
					$btx->amount = $this->toSatoshi($vout->whereIn('address', $mine_to)->sum('value'));
					$btx->confirmations = isset($block->confirmations)?$block->confirmations:0;
					$btx->blockHeight = $block->block_no;
					$valid[] = $btx;
				}
			}
		}
		return collect($valid);
	}
	public function getBlock($hash){
		$method = 'getblock';
		$params = [$hash, true];
		return $this->rpcRequest($method, $params);
	}
	
	public function getBlockByNumber($number){
		$hash = $this->getBlockHash($number);
		return $this->getBlock($hash);
	}
	
	public function getBlockHash($number){
		$method = 'getblockhash';
		$params = [$number];
		return $this->rpcRequest($method, $params);
	}
	
	
	public function getTx($hash){
		$method = 'gettransaction';
		$params = [$hash];
		return $this->jsonRequest($method, $params);
	}
	
	public function currentBlock(){
		$method = 'getinfo';
		return $this->jsonRequest($method);
	}
	
	public function feePerKB(){
		$data = $this->currentBlock();
		return $data->paytxfee;
	}
	
	public function getBalance($minconf, array $addresses=[]){
		$balance = 0;
		$method = 'getreceivedbyaddress';
		foreach($addresses as $address){
			$params = [$minconf , $address];
			$bal = $this->rpcRequest($method, $params);
			$balance = bcadd($balance , $bal , 8 );
 		}
		return $balance;
	}
	
}

