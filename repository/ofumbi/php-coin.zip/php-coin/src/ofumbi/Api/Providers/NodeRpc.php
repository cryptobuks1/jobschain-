<?php
namespace ofumbi\Api\Providers;
use ofumbi\Api\Providers\Provider;
use ofumbi\Api\ApiInterface;
use Graze\GuzzleHttp\JsonRpc\Client;

class NodeRpc extends Provider
{
    
    public function __construct( $url, $username , $password )
    {
        parent::__construct( $url, $username , $password );
    }
	
	
	public function getBlockByNumber($number){
		$hash = $this->getblockhash((int)$number);
		return $this->getblock($hash,true);
	}
	
	public function addressTx(\Illuminate\Support\Collection $addresses , $blocks = []){
		$valid = [];
		$adrs  =   $addresses->pluck('address')->all();
		$utxo  =  $this->listunspent(1 ,999999,$adrs );
		$src = $addresses->groupBy('address');
		if(count($utxo)){
			foreach($utxo as $utx){
				$btx = new \ofumbi\BTX;
				$btx->type = 'receive'; 
				$btx->to = $utx->address;
				$btx->hash = $utx->txid ;
				$btx->confirmations = $utx->confirmations;
				$btx->amount =  $utx->amount;
				$btx->address = $src[$utx->address]->first();
				$btx->blockheight = time();
				$btx->from = NULL;
				$btx->fee = NULL;
				$valid[] = $btx;
			}
		}
		return collect($valid);
	}
	
	public function addressBalance(\Illuminate\Support\Collection $addresses ){
		$valid = [];
		$adrs  =   $addresses->pluck('address')->all();
		$utxo  =  $this->listunspent(1 ,999999,$adrs );
		$src = $addresses->groupBy('address');
		$bal = 0;
		if(count($utxo)){
			foreach($utxo as $utx){
				$bal =  bcadd($bal, $utx->amount , 8);
			}
		}
		return $bal;
	}
	
	public function __call($method, $params){
		$res = $this->jsonRequest($method,  array_values($params));
		return $res->result??$res;
	}
	
	
	
}

