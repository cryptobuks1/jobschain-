<?php
namespace ofumbi\Api;
use ofumbi\Api\Providers\Insight;
use ofumbi\Api\Providers\Chainso;
use Graze\GuzzleHttp\JsonRpc\Client;
use ofumbi\Api\ApiInterface;

class BTC implements ApiInterface
{
	
	public $bip44index = '0';
	public  $apiOne ,  // api providers
			$apiTwo , 
			$apiThree ,  
			$apiFour, 
			$apiFive, 
			$apiSix,
			$apiSeven, 
			$net;

    public function __construct() // well use varoius api to handle rate limmiting
    {
		$this->net = $this->network();
		//feePerKB
		$this->apiOne = new Insight('https://blockexplorer.com/api/'); //
		//addressTx
		$this->apiTwo = new Insight('https://insight.bitpay.com/api/');  // getTx
		$this->apiThree = new Insight('https://explorer.bitcoin.com/api/btc/');
		//listunspent
		$this->apiFour = new Insight('https://btc-bitcore1.trezor.io/api/');  //listunspent
		//getBalance
		$this->apiFive = new Insight('https://btc-bitcore2.trezor.io/api/');	// balance 
		//sendrawtransaction
		$this->apiSix = new Insight('https://btc-bitcore3.trezor.io/api/'); 
		//currentBlock // getTx
		$this->apiSeven = new Insight('https://btc.coin.space/api/');  
	}
	
	 /**
     * @return NetworkInterface
     * @throws \Exception
     */
    protected function network()
    {
        return \BitWasp\Bitcoin\Network\NetworkFactory::bitcoin();
    }
	
	public function sigHash(){
		return  \BitWasp\Bitcoin\Transaction\SignatureHash\SigHash::ALL;
	}

   
	
	public function getNetwork(){
		return $this->net;
	}
	
	//bitpay
	public function addressTx(\Illuminate\Support\Collection $addresses , $blocks = []){
		return $this->apiTwo->addressTx($addresses, $blocks);
	}
	
	//trezor
	public function listunspent($minconf, array $addresses=[], $max = null){
		return $this->apiFour->listunspent($minconf, $addresses, $max);
	}
	
	public function getBalance($minConf, array $addresses=[]){
		return $this->apiFive->getBalance($minConf, $addresses );
	}
	
	public function importaddress($address,$wallet_name =null,$rescan =null){
		return false;
	}
	
	public function sendrawtransaction( $hexRawTx ){
		return $this->apiSix->sendrawtransaction( $hexRawTx );
	}
	

	public function getBlock($hash){
		return $this->apiOne->getBlock($hash);
	}
	
	public function getBlockByNumber($number){
		return $this->getBlock($number);
	}
	
	public function getTx($hash){
		return $this->apiSeven->getTx($hash);
	}
	
	public function currentBlock(){
		return $this->apiSeven->currentBlock();
	}
	
	public function feePerKB(){
		return $this->apiOne->feePerKB();;
	}
	
	
	
	
}

