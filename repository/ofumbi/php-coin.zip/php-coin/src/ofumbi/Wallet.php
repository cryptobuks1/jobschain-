<?php
namespace ofumbi;
Illuminate\Support\Collection;

class Wallet
{
	public $addresses;
	public function __construct(){
		$this->addresses = $addresses;
	}
}

